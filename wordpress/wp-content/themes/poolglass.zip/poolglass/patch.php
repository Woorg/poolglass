<?php
echo 'Путь к корневой папке: '.$_SERVER['DOCUMENT_ROOT'].'';
?>