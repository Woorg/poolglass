<?php return array(
    'root' => array(
        'name' => '__root__',
        'pretty_version' => 'dev-main',
        'version' => 'dev-main',
        'reference' => 'e0a88eb7da3fc43c8a72f8f7b343a74726962569',
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => 'dev-main',
            'version' => 'dev-main',
            'reference' => 'e0a88eb7da3fc43c8a72f8f7b343a74726962569',
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'htmlburger/carbon-fields-yoast' => array(
            'pretty_version' => 'v1.0.1',
            'version' => '1.0.1.0',
            'reference' => '9fceee862838d36674086b285749816e3758feb6',
            'type' => 'library',
            'install_path' => __DIR__ . '/../htmlburger/carbon-fields-yoast',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
